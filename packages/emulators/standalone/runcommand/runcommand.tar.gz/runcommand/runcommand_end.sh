#!/bin/sh

# Screen / Records Path
SCREENSHOT_PATH="/storage/.config/retroarch/screenshots"
RECORDS_PATH="/storage/.config/retroarch/records"

# roms Path
EMULATOR_PATH=$(dirname "$2")
ROM_BASE_PATH=$(dirname "$EMULATOR_PATH")
EMULATOR_SNAP_PATH=$EMULATOR_PATH/snap
EMULATOR_MNG_PATH=$EMULATOR_PATH/mng

echo "" >> $LOG_FILE
echo "=== runcommand_end" >> $LOG_FILE



######################################################################################################
# screenshot / records 옮기기 #
######################################################################################################

echo "- screenshot / records 옮기기" >> $LOG_FILE
find $SCREENSHOT_PATH -type f | sort -n | while read entry
do
	moveEntry="${entry:0:`expr ${#entry} - 18`}"
	echo "num of entry : ${#entry}"
	echo `expr ${#entry} - 18`
	mv "$entry" "$moveEntry.png"
	echo "$entry"
	echo "$moveEntry"
done

if [ ! -d "$EMULATOR_SNAP_PATH" ] ; then
	mkdir $EMULATOR_SNAP_PATH
fi

if [ "$EMULATOR" != "arcade" -a "$EMULATOR" != "mame" -a "$EMULATOR" != "fbneo" -a "$EMULATOR" != "mame-advmame" -a "$EMULATOR" != "hbmame" -a "$EMULATOR" != "fba" -a "$EMULATOR" != "fbn" ];then
	mv -f $SCREENSHOT_PATH/* $EMULATOR_SNAP_PATH >> $LOG_FILE
else
	cp -f $SCREENSHOT_PATH/* $EMULATOR_SNAP_PATH >> $LOG_FILE
	mv -f $SCREENSHOT_PATH/* $ROM_BASE_PATH/arcade/snap >> $LOG_FILE
fi

find $RECORDS_PATH -type f | sort -n | while read recordsEntry
do
	moveEntry="${recordsEntry:0:${#recordsEntry}-18}"
	mv "$recordsEntry" "$moveEntry.mkv"
done

if [ ! -d "$EMULATOR_SNAP_PATH" ] ; then
	mkdir $EMULATOR_SNAP_PATH
fi


echo "FFMPEG FILE : ffmpeg -i "$RECORDS_PATH/$ROM_FILENAME.mkv" -codec copy "$RECORDS_PATH/$ROM_FILENAME.mp4" -y" >> $LOG_FILE
#ffmpeg -i "$RECORDS_PATH/$ROM_FILENAME.mkv" -codec copy "$RECORDS_PATH/$ROM_FILENAME.mp4"
#rm -rf $RECORDS_PATH/*.mkv
if [ "$EMULATOR" != "arcade" -a "$EMULATOR" != "mame" -a "$EMULATOR" != "fbneo" -a "$EMULATOR" != "mame-advmame" -a "$EMULATOR" != "hbmame" -a "$EMULATOR" != "fba" -a "$EMULATOR" != "fbn" ];then
	mv -f $RECORDS_PATH/* $EMULATOR_SNAP_PATH >> $LOG_FILE
else
echo "step9" > /dev/pts/0
	cp -f $RECORDS_PATH/* $EMULATOR_SNAP_PATH
	mv -f $RECORDS_PATH/* $ROM_BASE_PATH/arcade/snap
fi
######################################################################################################




# 세이브정보 저장하기
echo "" >> $LOG_FILE
echo "- 퀵 세이브 포인트 정보 저장하기" >> $LOG_FILE

# ls -t '/roms/gba/건스타 슈퍼 히어로즈 (한글)'.state*.png | while read line
rm -f "$EMULATOR_PATH/$ROM_FILENAME".saveInfo
rm -f "$EMULATOR_PATH/$ROM_FILENAME".state.auto

ls -t "$EMULATOR_PATH/$ROM_FILENAME".state*.png | while read line
do
	SAVEFILENAME=`basename "$line"`
	SAVESTATEFILE="${SAVEFILENAME%.*}"
	(printf "$line|" && ls -alh --time-style='+%Y-%m-%d %H:%M:%S' "$EMULATOR_PATH/$SAVESTATEFILE" | awk '{print $6, $7"|"$5}') >> "$EMULATOR_PATH/$ROM_FILENAME".saveInfo
done



