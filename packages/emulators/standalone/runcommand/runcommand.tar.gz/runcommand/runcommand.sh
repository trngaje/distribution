#!/bin/bash

SCRIPT_PATH=$(dirname $(realpath $0))
#source "$SCRIPT_PATH/runcommand.cfg"

# Runcommand Path
RUNCOMMAND_PATH="$SCRIPT_PATH"

# Retroarch PATH( 32bit / 6bit(default) )
#HOME_PATH=`echo ~`
HOME_PATH="/storage"
#HOME=$HOME_PATH

cd "$HOME"

RETROARCH_EXEC="/usr/bin/retroarch"
CORE_PATH="/usr/lib/libretro"


# Log File Path
LOG_FILE="$RUNCOMMAND_PATH/log.txt"

###############################################################################

# ARG
EMULATOR=$1
ROM=$2
ROM_TINY="${ROM##*/}"
ROM_FILENAME="${ROM_TINY%.*}"

export EMULATOR
export ROM_FILENAME
export LOG_FILE
################################################################################



func_LoadEmulatorCfg()
{
	## EMULATOR CORE CFG LOAD ###################################################
	if [ -f "$RUNCOMMAND_PATH/cfg/$EMULATOR.cfg" ] ; then
		source "$RUNCOMMAND_PATH/cfg/$EMULATOR.cfg"
		echo "CFG LOAD : $RUNCOMMAND_PATH/cfg/$EMULATOR.cfg" >> $LOG_FILE
	else
		echo "CFG LOAD ERROR : $RUNCOMMAND_PATH/cfg/$EMULATOR.cfg" >> $LOG_FILE

		exit 0
	fi
	
	if [ ! -d "$RUNCOMMAND_PATH/$EMULATOR" ] ; then
		mkdir $RUNCOMMAND_PATH/$EMULATOR
	fi
	
	echo "DEFAULT CORE : $DEFAULT" >> $LOG_FILE
	#############################################################################

}


# 게임에 설정된 코어 읽어오기
func_LoadGameCore()
{
	## EMULATOR CORE CFG LOAD ###################################################
	if [ -f "$RUNCOMMAND_PATH/$EMULATOR/$ROM_TINY.cfg" ] ; then
		GAME_DEFAULT=`cat "$RUNCOMMAND_PATH/$EMULATOR/$ROM_TINY.cfg"`
	else
		GAME_DEFAULT=""
	fi
	############################################################################
	
	echo "GAME_CORE : $GAME_DEFAULT" >> $LOG_FILE
	
}

func_GameCoreRemove()
{
	echo "" >> $LOG_FILE
	echo "=== func_GameCoreRemove" >> $LOG_FILE
	
	rm -f "$RUNCOMMAND_PATH/$EMULATOR/$ROM_TINY.cfg"
	GAME_DEFAULT=""
}


# 런커맨드를 거치지 않고 바로 실행
func_LaunchImmediately()
{
	echo "" >> $LOG_FILE
	echo "=== func_LaunchImmediately" >> $LOG_FILE
	
	func_LoadEmulatorCfg
	func_LoadGameCore
	func_LaunchGame
	
	exit 0
}

# 게임 실행
func_LaunchGame()
{
	echo "" >> $LOG_FILE
	echo "=== func_LaunchGame" >> $LOG_FILE
	


	############################################### retroarch exec ###############################################################
	if [ "$GAME_DEFAULT" == "" ]; then
		CORE=$DEFAULT
	else
		CORE=$GAME_DEFAULT
	fi
	

	#perfmax

	#$SCRIPT_PATH/xboxdrv_start.sh "$EMULATOR" "$CORE" "$ROM_FILENAME" > /dev/null 2>&1

	case "$CORE" in
		*".so"*) $RETROARCH_EXEC -v -L "$CORE_PATH/$CORE" "$ROM"
			;;
		*) $CORE "$ROM" 
			;;
	esac


	#$SCRIPT_PATH/xboxdrv_end.sh "$EMULATOR" "$CORE" "$ROM_FILENAME" 
	$SCRIPT_PATH/runcommand_end.sh "$EMULATOR" "$ROM"
	#perfnorm
#	sudo killall -w ffplay
	exit 0
}


##### Main Function ##################################################################

#echo "performance" | sudo tee /sys/devices/system/cpu/cpufreq/policy2/scaling_governor


echo "EMULATOR : $EMULATOR" > $LOG_FILE
echo "ROM_FULL_PATH : $ROM" >> $LOG_FILE
echo "ROM : $ROM_TINY" >> $LOG_FILE
echo "ROM_FILENAME : $ROM_FILENAME" >> $LOG_FILE




	func_LaunchImmediately


exit 0
clear
#######################################################################################
