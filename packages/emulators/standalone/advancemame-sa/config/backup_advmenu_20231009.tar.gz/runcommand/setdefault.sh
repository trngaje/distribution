#!/bin/sh
DEFAULT=$1
CORE_CONF_FILE="/mnt/SDCARD/runcommand/cfg/"$2".cfg"

#echo DEFAULT =$DEFAULT > /dev/pts/1
#echo CORE_CONF_FILE=$CORE_CONF_FILE > /dev/pts/1
sed -i '/DEFAULT=/c\DEFAULT=\"'"${DEFAULT}"'\"' ${CORE_CONF_FILE}
